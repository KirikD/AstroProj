# Contributing

At this time, the repo is not accepting external contributions in the form of PRs. 

We encourage you to submit bugs, suggestions, and feedback as [GitHub issues](https://github.com/Unity-Technologies/arfoundation-samples/issues).