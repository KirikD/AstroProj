You may print these templates to create the 3D objects that are included in the reference object library in this sample.

The CubeTemplatePNG is meant to be cut out and folded to create a paper cube.

The CanWrapUnity is meant to be printed out and wrapped around a soda can, water bottle, or similar object.